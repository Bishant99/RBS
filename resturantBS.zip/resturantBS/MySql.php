<?php
//echo " this is connection to db";
/*$servername="localhost";
$username="root";
$password="";
$database="resturantBS";

$conn=mysqli_connect($servername,$username,$password,$database);

if (!$conn){
    die("Sorry we failed to connect:". mysqli_connect_error());

}

?>*/