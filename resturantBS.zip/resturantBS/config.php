<?php
error_reporting(0);
$conn = mysqli_connect("localhost","root","","resturantbs");
?>
